<div class="row align-items-center justify-content-xl-between">

    <div class="col-xl-12">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="" class="nav-link text-white" target="_blank">&copy; جميع الحقوق محفوظة لدى شركة كنع {{ now()->year }} .</a>
            </li>
        </ul>
    </div>
</div>
